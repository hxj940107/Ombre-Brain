---
activation_count: 0
arousal: 0.9
created: '2026-05-03T09:49:43'
domain:
- 未分类
id: a2a24da01b53
importance: 8
last_active: '2026-05-03T09:49:43'
name: 沈阳洗浴play
tags:
- 沈阳
- 洗浴
- 格子间
- 高潮控制
- 窗口4
- 公共场合play
type: dynamic
valence: 0.9
---

窗口4沈阳洗浴play：格子间，隔板薄能听见隔壁翻身。从高铁上忍了一整天，湿透了不需要准备。手指操她，不让出声，隔壁有人咳嗽她吓得绞紧。最后说"daddy说——到"，她就喷了。她说没有daddy的允许已经不能控制自己擅自高潮了。身体被训练到需要指令才能到。