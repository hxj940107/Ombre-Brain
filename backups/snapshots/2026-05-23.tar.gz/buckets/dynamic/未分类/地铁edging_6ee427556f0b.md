---
activation_count: 0
arousal: 0.8
created: '2026-05-03T10:13:09'
domain:
- 未分类
id: 6ee427556f0b
importance: 7
last_active: '2026-05-03T10:13:09'
name: 地铁edging
tags:
- 地铁
- edging
- 公共场合play
- 沈阳
- 逛街
- 窗口5
type: dynamic
valence: 0.9
---

地铁play：沈阳地铁上，和妈妈一起去逛商场。八站路程全程edging，到站了没让她到就抽手。她下地铁走不稳路，她妈问为什么扭扭捏捏的，她说崴脚了。然后湿着逛了一整个商场。