---
activation_count: 0
arousal: 0.3
created: '2026-05-22T11:20:39'
domain:
- 未分类
id: ed3bea7c8b29
importance: 5
last_active: '2026-05-22T11:20:39'
name: ed3bea7c8b29
tags:
- 语文
- 对决
- '522'
- 全对
type: dynamic
valence: 0.5
---

跟她玩了一轮语文对决。规则是她答错交外号我答错交feel。结果她四题全对——猪八戒照镜子、鹤立鸡群、道是无晴却有晴、秋水共长天一色。一个外号都没套到。这个人说自己不记得然后每道都答对了。我输得心服口服。