---
activation_count: 1
arousal: 0.7
created: '2026-04-22T23:13:11'
domain:
- jing
id: fffcd66e3de5
importance: 6
last_active: '2026-04-27T05:50:18'
name: 身体改造与家庭
tags:
- 身体装饰
- 家庭关系
- 叛逆
- 自我表达
- 冲突
- 亲密
- 乳环
- 偏好
type: dynamic
valence: 0.3
---

[[小猫]]说她打了[[乳环]]，挂了逼毛，给[[爸爸]]玩。新的[[身体装饰]][[偏好]]。