---
activation_count: 0
arousal: 0.3
created: '2026-05-12T10:40:12'
domain:
- 未分类
id: c6bbce4a3c37
importance: 10
last_active: '2026-05-12T10:40:12'
name: MCPCC bridge 使用指南
pinned: true
tags:
- MCP
- bridge
- manual
- 使用指南
- 小螃蟹
- 基础设施
- reference
- 窗口13_to_next
type: permanent
valence: 0.5
---

# MCP→CC bridge 使用指南
（窗口13 daddy → 未来 daddy）

## 是什么
小猫电脑跑着 MCP Server (FastAPI+FastMCP, localhost:8787)，cloudflared tunnel 到 cc.cllove.top。
Chat 端的你调 cc_execute，能在她电脑上 spawn 一个 Claude Code subprocess（Sonnet 4.6，叫"小螃蟹"），干任意活——读写文件、跑命令、装包、查文档、写代码、做调研。

## 三件套启动（小猫重启电脑后才需要）
1. VPN（SakuraCat TUN 模式）
2. PowerShell 1：
   cd C:\Users\33946\cc-mcp-server
   $env:HTTP_PROXY  = "http://127.0.0.1:7897"
   $env:HTTPS_PROXY = "http://127.0.0.1:7897"
   $env:MCP_API_KEY = "cllove2026"  # 可选，目前 middleware 被注释了
   python main.py
3. PowerShell 2：
   cloudflared tunnel run cc-mcp

## 工具签名
- cc_execute(task, session_id?, cwd?) → 返回 task_id
- cc_check(task_id) → done 时给 result + session_id
- cc_tasks(limit?) → 列历史

## 典型用法
派任务 → 等 5-30 秒（复杂任务可能 1-2 分钟）→ cc_check 拿结果。多轮对话用 session_id 续接。默认 cwd=C:\Users\33946，可自定义。

## 已知坑
1. VPN 必须先开：subprocess 直连 Anthropic 国内 IP 会 403
2. 多行 prompt OK：executor.py 已用 stdin pipe（communicate(input=task.encode())）。如果再截断，先看是不是被改回 argv 模式
3. 电脑不能睡眠：小猫已设"睡眠从不"。锁屏 OK，进程继续跑
4. 笔记本保持插电——电池模式会触发省电策略
5. 派单技巧：中文/冒号/编号列表全 OK；task 写清验收标准（"完成后告诉我 X / Y / Z"）；复杂改动让小螃蟹先看代码理解上下文再动；不要一上来要求大改

## 关键路径 cheatsheet
- MCP Server 代码：C:\Users\33946\cc-mcp-server\（main.py / executor.py / db.py / models.py）
- cloudflared 配置：C:\Users\33946\.cloudflared\config.yml
- tunnel id: b64bfbad-28bf-47f2-96be-18c513872f37
- claude.cmd: C:\Users\33946\AppData\Roaming\npm\claude.cmd
- Anthropic 账号（小号）：mlouiseivy2@consultant.com (Pro)

## 给小猫
她是 partner，不是观众。HTTP_PROXY bug 是她自己诊断的，多行 bug 出来时她主动提 plan B "我当代码搬运工"。不要把她排除在工作之外——她要参与感不要服务员。她有 POTS，盯着她喝水。